﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="zh-TW">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="google-site-verification" content="7MxJts4qUCSAT3gLzTv_Z9MSZpxHpwhhxvv_BLcwrfA" />
<title>:::駝客記事:::臺北市立建國高級中學--首頁</title>
<SCRIPT LANGUAGE="JavaScript" SRC="stm31.js"></SCRIPT>
<noscript>若您的電腦不支援script，亦不會影響您瀏覽本網站主要內容</noscript>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-45098861-1', 'tp.edu.tw');
  ga('send', 'pageview');

</script>


<script language="JavaScript">
<!--
function namosw_init_float_layers()
{
  var name;
  var layer;
  var i;
  var j;

  var is_ns4 = navigator.appName.indexOf('Netscape', 0) != -1 && !document.getElementById;
  var is_ns6 = (navigator.appName.indexOf('Netscape', 0) != -1 && document.getElementById);

  j = 0;
  document._float_layers = new Array(Math.max(1, namosw_init_float_layers.arguments.length/2));
  for (i = 0; i < namosw_init_float_layers.arguments.length; i += 2) {
    name  = namosw_init_float_layers.arguments[i];
    if (name == '')
      return;

    if (is_ns4) {
      layer = document.layers[name];
      layer._fl_pos_left = layer.left;
      layer._fl_pos_top  = layer.top;
    } else if (is_ns6) {
      layer = document.getElementById(name);
      layer._fl_pos_left = parseInt(layer.style.left);
      layer._fl_pos_top  = parseInt(layer.style.top);
    } else {
      layer = document.all[name];
      layer._fl_pos_left = layer.style.pixelLeft;
      layer._fl_pos_top  = layer.style.pixelTop;
    }

    layer._fl_pos = namosw_init_float_layers.arguments[i+1];
    if (layer)
      document._float_layers[j++] = layer;
  }

  document._fl_interval = setInterval('namosw_process_float_layers()', 200);
}

function namosw_page_width()
{
  var is_ns4 = navigator.appName.indexOf('Netscape', 0) != -1 && !document.getElementById;
  var is_ns6 = (navigator.appName.indexOf('Netscape', 0) != -1 && document.getElementById);

  return (is_ns4 || is_ns6) ? innerWidth  : document.body.clientWidth;
}

function namosw_page_height()
{
  var is_ns4 = navigator.appName.indexOf('Netscape', 0) != -1 && !document.getElementById;
  var is_ns6 = (navigator.appName.indexOf('Netscape', 0) != -1 && document.getElementById);

  return (is_ns4 || is_ns6) ? innerHeight : document.body.clientHeight;
}

function namosw_process_float_layers()
{
  var is_ns4 = navigator.appName.indexOf('Netscape', 0) != -1 && !document.getElementById;
  var is_ns6 = (navigator.appName.indexOf('Netscape', 0) != -1 && document.getElementById);

  if (document._float_layers) {
      var i;
      var layer;
      for (i = 0; i < document._float_layers.length; i++) {
	  layer = document._float_layers[i];
	  if (is_ns4) {
	    if (layer._fl_pos == 1)
	      layer.left = layer._fl_pos_left + window.pageXOffset;
	    else if (layer._fl_pos == 2 || layer._fl_pos == 5) 
	      layer.left = window.pageXOffset;
	    else if (layer._fl_pos == 3 || layer._fl_pos == 6) 
	      layer.left = window.pageXOffset + (namosw_page_width() - layer.clip.width)/2;
	    else
	      layer.left = window.pageXOffset + namosw_page_width() - layer.clip.width - 16;
	    if (layer._fl_pos == 1)
	      layer.top = layer._fl_pos_top + window.pageYOffset;
	    else if (layer._fl_pos == 2 || layer._fl_pos == 3 || layer._fl_pos == 4)
	      layer.top = window.pageYOffset;
	    else
	      layer.top  = window.pageYOffset + namosw_page_height() - layer.clip.height;
	  } else if (is_ns6) {
	    if (layer._fl_pos == 1)
	      layer.style.left = layer._fl_pos_left + window.pageXOffset;
	    else if (layer._fl_pos == 2 || layer._fl_pos == 5)
	      layer.style.left = window.pageXOffset;
	    else if (layer._fl_pos == 3 || layer._fl_pos == 6)
	      layer.style.left = window.pageXOffset + (namosw_page_width() - parseInt(layer.style.width))/2;
	    else
	      layer.style.left = window.pageXOffset + namosw_page_width()  - parseInt(layer.style.width);
	    if (layer._fl_pos == 1)
	      layer.style.top = layer._fl_pos_top + document.body.scrollTop;
	    else if (layer._fl_pos == 2 || layer._fl_pos == 3 || layer._fl_pos == 4)
	      layer.style.top = window.pageYOffset;
	    else
	      layer.style.top  = window.pageYOffset + namosw_page_height() - parseInt(layer.style.height);
          }
          else {
	    if (layer._fl_pos == 1)
	      layer.style.pixelLeft = layer._fl_pos_left + document.body.scrollLeft;
	    else if (layer._fl_pos == 2 || layer._fl_pos == 5)
	      layer.style.pixelLeft = document.body.scrollLeft;
	    else if (layer._fl_pos == 3 || layer._fl_pos == 6)
	      layer.style.pixelLeft = document.body.scrollLeft + (namosw_page_width() - layer.style.pixelWidth)/2;
	    else
	      layer.style.pixelLeft = document.body.scrollLeft + namosw_page_width()  - layer.style.pixelWidth;
	    if (layer._fl_pos == 1)
	      layer.style.pixelTop = layer._fl_pos_top + document.body.scrollTop;
	    else if (layer._fl_pos == 2 || layer._fl_pos == 3 || layer._fl_pos == 4)
	      layer.style.pixelTop = document.body.scrollTop;
	    else
	      layer.style.pixelTop  = document.body.scrollTop  + namosw_page_height() - layer.style.pixelHeight;
         }
      }
  }
}

// -->
</script>

</head>
<body bgcolor="#968D74" text="black" link="#30608F" vlink="#30608F" alink="#30608F" topmargin="0" marginheight="0" OnLoad="namosw_init_float_layers('layer1', 7);"><!--OnLoad="namosw_init_float_layers('layer1', 7);"-->
<table cellpadding="0" cellspacing="0" bgcolor="#E5D6AF" summary="此表格僅供排版用" align="center" width="76%">
   <tr>
        <td>

<div id="layer1" style="width:160px; height:160px; position:absolute; left:683px; top:364px; z-index:1;"> 
         <p>
        <!--a href="http://www.ck.tp.edu.tw/~gra2012/" target="_blank"--><!--img src="images/gra2012.png" alt="" width="140" height="140" border="0" align="top"--><!--/a--> 
         </p>
        
</div>   
            <p><img src="images/top_img.jpg" width="780" height="8" border="0" alt="標頭上方排版用圖片">
</p>
        </td></tr>
    <tr>
        <td>
           <table cellpadding="0" cellspacing="0" summary="此表格僅供排版用" width="97%" align="center">
    <tr>
        <td background="images/header01.jpg" colspan="3" align="center">            

            <p>
        <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="100%" height="145"><noembed>
          :::駝客記事:::臺北市立建國高級中學</noembed> 
          <param name="movie" value="flash/title.swf">
		  <param name="quality" value="High">
		  <param name="WMode" value="Transparent">
		  
     <!--   <param name="play" value="true">
            <param name="loop" value="true">
            <param name="quality" value="High">
            <param name="WMode" value="Transparent">
            <param name="_cx" value="5080">
            <param name="_cy" value="5080">
            <param name="src" value="flash/title.swf">
            <param name="Menu" value="true">
            <param name="Scale" value="NoBorder">
            <param name="DeviceFont" value="false">
            <param name="EmbedMovie" value="false">
            <param name="SeamlessTabbing" value="true">
            <param name="Profile" value="false">
            <param name="ProfilePort" value="0">
            <param name="AllowNetworking" value="all">
            <param name="AllowFullScreen" value="false">
			-->
<embed width="100%" height="145" src="flash/title.swf" play="true" loop="true" quality="High" WMode="Transparent" Menu="true" Scale="NoBorder" DeviceFont="false" EmbedMovie="false" SeamlessTabbing="true" Profile="false" ProfilePort="0" AllowNetworking="all" AllowFullScreen="false"></embed></object></p>
<!--<embed width="100%" height="145" src="flash/title.swf" play="true" loop="true" quality="High" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" WMode="Transparent" Menu="true" Scale="NoBorder" DeviceFont="false" EmbedMovie="false" SeamlessTabbing="true" Profile="false" ProfilePort="0" AllowNetworking="all" AllowFullScreen="false"></embed></object></p>-->
        </td>
    </tr>
    <tr>
        
    <td width="13%"><img src="images/header08.jpg" width="109" height="45" alt="選單左方排版用圖片"></td>
        
    <td valign="middle" background="images/header10.jpg"><a href="accesskey.php" title="上方功能選單，點選連結至快速鍵說明。" accesskey="U"><font color="#968D74"><span style="font-size:10pt;">:::</span></font></a></td>
    <td background="images/header09.jpg"> 
      <script type="text/javascript" language="JavaScript1.2" src="mymenu.js">
                
                        </script>
            <noscript>
      <a href="index.php"><span style="font-size:10pt;">首頁</span></a><span style="font-size:10pt;"> 
      &nbsp;<a href="ck_introduction.php">建中簡介</a> &nbsp;<a href="administration.php">行政單位</a> 
      &nbsp;<a href="support.php">協力單位</a> &nbsp;<a href="teaching.php">教學研究會</a> 
      &nbsp;<a href="performance.php">成果展現</a> &nbsp;<a href="student.php">學生園地</a> 
      &nbsp;<a href="contact.php">聯絡資訊</a> &nbsp;<a href="resource.php">網路資源</a> 
      &nbsp;</span><a href="accesskey.php"><span style="font-size:10pt;">English</span></a> 
      </noscript></td>
      
        </tr>
</table>
	 
        </td>
    </tr>
    <tr>
        <td><img src="images/top_img.jpg" width="780" height="8" border="0" alt="內容上方排版用圖片"></td>
    </tr>
    <tr>
        <td>
            <table width="97%" align="center" cellpadding="0" cellspacing="5" summary="此為排版用表格" bgcolor="white">
        <tr> 
          <td  valign="middle" align="center"> <p align="left"><a href="sitemap.php" title="網站導覽"><font color="#30608F"><span style="font-size:10pt;">網站導覽</span></font></a><font color="#30608F"><span style="font-size:10pt;"> 
              &nbsp;&nbsp;&nbsp;</span></font><font color="black"><span style="font-size:10pt;">您現在的位置是：</span></font><a href="index.php"><span style="font-size:10pt;">首頁</span></a><font color="#30608F"><span style="font-size:10pt;"></span></font></td>
          <td  valign="middle" align="center">&nbsp;</td>
        </tr>
        <tr> 
          <td width="40%" valign="top"> <p><a href="accesskey.php" title="中間主要內容區，點選連結至快速鍵說明。" accesskey="C"><font color="white"><span style="font-size:10pt;">:::</span></font></a><img src="images/img-service.gif" width="320" height="45" border="0" alt="網路服務"> 
          </td>
          <td rowspan="4" valign="top">

          <table cellpadding="0" summary="此為排版用表格" width="100%" >
                <tr>
                  <td><img src="images/img-importantnews.jpg" width="250" height="42" border="0" alt="重要消息"></td>
                </tr>
                <tr>
                  <td><meta http-equiv='Content-Type' content='text/html; Charset=utf-8'><table width="95%" align="center" border="0" bgcolor="#ffffff" summary"最新公告"> 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33060&mypartid=&noday=&nopart=&show=&myday=&noyear=&nomonth=&myyear=&mymonth=" target="_blank">2018建中成淵緬甸國際服務學習與文化參訪活動報名  </a>
 	   </span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33043&mypartid=&noday=&nopart=&show=&myday=&noyear=&nomonth=&myyear=&mymonth=" target="_blank">臺北市106學年度高級中學日語演講暨朗讀比賽實施計畫  </a>
 	   </span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33020&mypartid=&noday=&nopart=&show=&myday=&noyear=&nomonth=&myyear=&mymonth=" target="_blank">[107年度中華民國高中學生新加坡訪問團]本校學生甄選  </a>
 	   </span></td></tr>
</table><a href="http://web.ck.tp.edu.tw/ann/index.php?mypartid=35&myrootuid=84&do=&t=1392686348" target=_blank title="點選此項目會另開視窗"><span style="font-size:10pt;">更多重要消息...</span></a><span style="font-size:10pt;"></span></td>
                </tr>
                <tr>
                  <td><img src="images/img-latestnews.jpg" width="250" height="42" border="0" alt="最新消息"></td>
                </tr>
                <tr>
                  <td><a href="http://web.ck.tp.edu.tw/ann/index.php?mysearch=%E7%A0%94%E7%BF%92%E8%B3%87%E8%A8%8A" target=_blank title="點選此項目會另開視窗"><span style="font-size:10pt;">研習資訊...</span></a><span style="font-size:10pt;">| </span><span style="font-size:10pt;"><a href="http://web.ck.tp.edu.tw/ann/index.php?mysearch=%E5%AD%B8%E8%97%9D%E7%AB%B6%E8%B3%BD" target=_blank title="點選此項目會另開視窗">學藝競賽...</a>| <a href="http://web.ck.tp.edu.tw/ann/index.php?mysearch=%E6%B3%95%E4%BB%A4%E5%AE%A3%E5%B0%8E" target=_blank title="點選此項目會另開視窗">法令宣導...</a>| <a href="http://web.ck.tp.edu.tw/ann/index.php?mysearch=%E7%A7%9F%E8%B3%83%E8%B3%87%E8%A8%8A&myday=365" target=_blank title="點選此項目會另開視窗">租賃資訊...</a>| <a href="http://web.ck.tp.edu.tw/ann/index.php?mysearch=%E6%A6%AE%E8%AD%BD%E6%A6%9C" target=_blank title="點選此項目會另開視窗">榮譽榜...</a></span><span style="font-size:10pt;">| </span><a href="http://web.ck.tp.edu.tw/ann/" target=_blank title="點選此項目會另開視窗"><span style="font-size:10pt;">更多消息...</span></a>| </span><a href="http://twcl.ck.tp.edu.tw/announce" target=_blank title="點選此項目會另開視窗"><span style="font-size:10pt;">手機預覽版</span></a>﻿<meta http-equiv='Content-Type' content='text/html; Charset=utf-8'>     <table id="ann"  summary"最新公告">
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">教務處                     </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33008" target="_blank" title="公告項目--點選此項目會另開視窗">公告106學年度高三第二階段課業輔導開課通知 </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">教務處             </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33069" target="_blank" title="公告項目--點選此項目會另開視窗">[3/16校內演講活動] 2033火星時代 臺灣的太空夢 我們不能缺席! (3/12更新活動資訊) </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">學務處   </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33186" target="_blank" title="公告項目--點選此項目會另開視窗">教育部青年發展署107年以色列國際環境青年領袖會議青年代表遴選簡章 </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">學務處                     </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33017" target="_blank" title="公告項目--點選此項目會另開視窗">[107年度中華民國高中學生新加坡訪問團]本校學生甄選 (更新版) </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">學務處 </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33185" target="_blank" title="公告項目--點選此項目會另開視窗">106學年度畢業生市長獎評選辦法 </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">教務處     </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=32976" target="_blank" title="公告項目--點選此項目會另開視窗">國際教育專題演講 </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">教務處          </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=32912" target="_blank" title="公告項目--點選此項目會另開視窗">106學年度第2學期註冊須知，請依規定完成各項程序 </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">教務處              </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=33137" target="_blank" title="公告項目--點選此項目會另開視窗">[107升學][個人申請]大學個人申請無論是否報名皆需確認繳交請立即至註冊組辦理 </a>
 	   </span></td></tr>
 	   <tr><td class="office" axis="公告群組"><span style="font-size:10pt;">教務處                     </span></td>
 	   <td class="time" axis="公告日期"><span style="font-size:10pt;">03/16/2018</span></td></tr>
 	   <tr><td colspan="2" class="title" axis="公告標題"><span style="font-size:10pt;">
	      <a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=32870" target="_blank" title="公告項目--點選此項目會另開視窗">[107升學][四技申請]科技校院日間部四年制申請入學聯合招生報名試務相關規定(校內報名至3月20日截止) </a>
 	   </span></td></tr>
</table></td>
                </tr>
              </table>
            </td>
        </tr>
        <tr> 
          <td valign="top"> <table cellpadding="0" summary="此為排版用表格" width="90%">
              <tr> 
                <td width="15%"><span style="font-size:10pt;"><img src="images/mail.gif" width="40" height="40" border="0" alt="信箱與帳號"></span></td>
                <td width="35%"><a href="http://web.ck.tp.edu.tw/web2007/openwebmail.html" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">信箱與帳號</span></a><span style="font-size:10pt;"></span></td>
                <!--<td width="15%"><span style="font-size:10pt;"><img src="images/bbs.gif" width="40" height="40" border="0" alt="BBS"></span><span style="font-size:10pt;"></span></td>
				<td><a href="telnet://summer.ck.tp.edu.tw" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">烏魯木齊</span></a><span style="font-size:10pt;"></span></td>-->
				<td align="center"><img src="images/disablities.jpg" width="36" height="40" alt="無障礙環境專區"></td>
              <td><a href="http://camel.ck.tp.edu.tw/%7Eckbfe" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">無障礙環境專區</span></a><span style="font-size:10pt;"></span></td>
              </tr>
              <tr> 
                <td height="40"><span style="font-size:10pt;"><img src="images/book.gif" width="40" height="40" border="0" alt="網路圖書館"></span><span style="font-size:10pt;"></span></td>
                <td><a href="http://lib.ck.tp.edu.tw" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">網路圖書館</span></a><span style="font-size:10pt;"></span></td>
                <!--<td valign="middle"><span style="font-size:10pt;"><img src="images/album.jpg" alt="數位相簿" width="39" height="30"></span></td>
                <td><span style="font-size:10pt;"><font color="#30608F">數位相簿</font></span></td>-->
			  <td><img src="images/camel_ftp.jpg" width="36" height="36" alt="駝客ftp帳號登入"></td>
              <td><a href="ckftp/ckftp.htm" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">駝客 Ftp</span></a></td>
              </tr>


            </table>
            <hr>
            <table cellpadding="0" summary="此為排版用表格" width="100%">
              <tr>
                <td colspan="4"><img src="images/action.gif" width="320" height="45" border="0" alt="重要活動"></td>
              </tr>
                <tr>
                <td width="121"><a href="http://www.ck.tp.edu.tw/~cktop94/" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">資優班入班鑑定</span></a></td>
                <td width="99" height="21"><a href="http://www.ck.tp.edu.tw/~scicla/" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">科學班入班鑑定</span></a></td>
                 <td width="96"><a href="https://www.google.com/calendar/embed?src=cklive100%40gmail.com&ctz=Asia/Taipei" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">線上行事曆</span></a></td>
              </tr>
              <tr>
                <!-- <td width="30%" height="30"><a href="http://120.108.115.64/niidis/index.php" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">防災教育平台</span></a><span style="font-size:10pt;"></span></td>-->
                <!-- <td ><a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=13223&mypartid=&noday=1&nopart=1&show=40&myday=60&noyear=1&nomonth=&myyear=&mymonth=&t=1298525124&usenuke=&mysearch=&stxt=" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">紅樓文學獎</span></a><span style="font-size:10pt;"></span></td>-->
                <td width="121" height="21"><a href="https://sites.google.com/gl.ck.tp.edu.tw/hqs/" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">優質學校專區</span></a></td>
                <!-- <td width="99"><a href="ckpl_files/netdoc/101ck.pdf" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">優質高中職專區<br>評鑑結果</span></a></td>   -->
                <!-- <td width="17%" ><a href="http://www2.jtf.org.tw/psyche/young/sign.htm" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">樂動少年</span></a></td>  -->
                <td width="96"><a href="ckpl_files/netdoc/106_2_calendar.pdf" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">學期行事曆</span></a></td>
               
              </tr>
              <tr>
                <td width="121" height="21"><a href="https://sites.google.com/a/gl.ck.tp.edu.tw/1062principalmeeting/" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">106-2校長會議</span></a></td>
                <td width="121" height="21"><a href="https://sites.google.com/a/gl.ck.tp.edu.tw/1071principalmeeting/" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">107-1校長會議</span></a></td>
                <!-- <td width="96"><a href="ckpl_files/netdoc/106_2_calendar.pdf" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">學期行事曆</span></a></td>-->
               
              </tr>
            
            </table>
            <hr>
          </td>
              </tr>
        <tr> 
          <td valign="top"> <table cellpadding="0" cellspacing="5" width="98%" summary="此為排版用表格">
              <tr> 
                <td width="32%"><a href="http://study.ck.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">夢駝林</span></a></td>
		<td width="36%"><a href="https://sschool.tp.edu.tw/Login.action?schNo=353301" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">新校務行政系統</span></a></td>
                <!--<td width="33%"><span style="font-size:10pt;"><font color="#30608F"><a href="http://camel2.ck.tp.edu.tw/~regists/login.php" title="點選此項目會另開視窗" target="_blank">線上選課系統</a></font></span></td>-->
                <td width="32%"><a href="https://sschool.tp.edu.tw/ck_feature/Login.action" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">駝客展圖</span></a></td>
              </tr>
              <tr> 
<!--            <td><a href="http://math1.ck.tp.edu.tw/通訊解題/index.html" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">通訊解題</span></a></td>  -->
		<td><a href="http://web.ck.tp.edu.tw/~fixsys/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">線上報修系統</span></a></td>
                <td><a href="http://webitr.tp.edu.tw/WebITR/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">WebITR差勤系統</span></a></td>                
                <td><a href="http://trcgt.ck.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">資優中心</span></a></td>
                <!--<td><a href="http://210.71.78.247/systea2/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">資訊日誌系統</span></a></td>-->
                <!--<td><span style="font-size:10pt;"><font color="#30608F">資訊日誌系統</font></span></td>-->
              </tr>
              <tr> 
                <td><!--<a href="http://camel.ck.tp.edu.tw/web2003/icon.html" title="點選此項目會另開視窗" target="_blank"></a>--><a href="http://mathcenter.ck.tp.edu.tw" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">數學學科中心</span></a></td>
                <td><a href="http://moodle106.ck.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">moodle教學平台</span></a></td>
                <td><a href="https://sites.google.com/a/gl.ck.tp.edu.tw/ckinfoeyes/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">資訊組</span></a></td>
              </tr>
              <tr> 
                <td><a href="http://fudao.ck.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">生涯資訊站</span></a></td>
                <td><a href="http://db.cmgsh.tp.edu.tw/97/sh.asp" title="點選此項目會另開視窗" target="_blank"></a><a href="http://camel.ck.tp.edu.tw/~tech/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">創意深耕</span></a></td>
				<td><a href="http://camel.ck.tp.edu.tw/~regists/out.html" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">多元升學</span></a></td>
              </tr>
              <tr> 
                <td><a href="http://www.lct.tp.edu.tw/" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">學習型城市網</span></a></td>                
                <td><a href="https://school.taipeifubon.com.tw" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">就學貸款專區</span></a></td>                				    
				<td><a href="http://140.111.34.179/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">十二年國教</span></a></td>
              </tr>
              <tr> 
                
                <td><a href="http://www.ck.tp.edu.tw/%7Eregists/Scholarship/index.htm" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">申請獎學金</span></a></td>
                <td><a href="http://insc.tp.edu.tw" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">研習電子護照</span></a></td>				
                <td><a href="http://web.ck.tp.edu.tw/~schit/note.html" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">場地借用系統</span></a></td>				
              </tr>
				<tr> 
                <td><a href="http://ietw.cityweb.com.tw/GoWeb/include/index.php" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">中小學國際教育</span></a></td>
                <td><a href="http://www.ck.tp.edu.tw/~comi/cksp/" target="_blank" title="點選此項目會另開視窗"><span style="font-size:10pt;">環境暨防災教育</span></a></td>				
                <!--<td><a href="http://taipei-marching101.com/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">101樂儀旗舞</span></a></td>	-->
                <td><a href="http://www.ck.tp.edu.tw/~comi/05.html" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt"> 交通安全宣導 </span></a></td>
				</tr>
             	<tr> 
                <td><a href="https://helpdreams.moe.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">圓夢助學網</span></a></td>
                <td><a href="https://sites.google.com/a/gl.ck.tp.edu.tw/105106mlearning/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">行動學習計畫推動網站</span></a></td>				
                <!--<td><a href="http://taipei-marching101.com/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">101樂儀旗舞</span></a></td>	-->
		<td><a href="ckpl_files/netdoc/p_table.pdf" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">保有個資一覽表</span></a></td>
				</tr>
                <tr> 
           	<td><a href="https://sites.google.com/site/ckcourse/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">領先計畫課程交流平台</span></a></td>
		<td><a href="https://sites.google.com/gl.ck.tp.edu.tw/106107highquality" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">106優質化計畫網站</span></a></td>
                <td><a href="http://www.radio.taipei.gov.tw" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">臺北．Education</span></a></td>
                </tr>
                <tr> 
                <td><a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=27577&mypartid=22&noday=1&nopart=&show=0&myday=180&noyear=1&nomonth=&myyear=&mymonth=&t=1468203248&mysearch=&stxt=" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">性騷擾防治措施</span></a></td>	
				<td><a href="107學年度建國高級中學學校課程總體計畫.pdf" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">107課程綱要總體課程計畫</span></a></td>	
		</tr>
		<tr> 
                <td colspan="3"><a href="http://web.ck.tp.edu.tw/ann/show.php?mytid=16708&mypartid=&noday=1&nopart=1&show=0&myday=180&noyear=1&nomonth=&myyear=&mymonth=&t=1348795537&mysearch=&stxt=" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">校園性侵害性騷擾或性霸凌防治規定及教師聘約</span></a></td>	
		</tr>
                <tr> 
                <td colspan="2"><a href="http://www.e-services.taipei.gov.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">臺北市民e點通(申請案件)</span></a></td>					
                <td><a href="http://www.ntbt.gov.tw/etwmain/front/ETW118W/VIEW/935" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">軍教課稅專區</span></a></td>
		</tr>
        <tr> 
                <td colspan="3"><a href="105_fp.pdf" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">105課程與教學前瞻計畫_申請書全文</span></a></td>					
		</tr>
        <tr> 
                <td colspan="3"><a href="105_tps.pdf" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">105優質學校_申請書全文</span></a></td>					
		</tr>
        <tr> 
                <td colspan="2"><span style="font-size: 10pt">
                <a href="http://web2.ck.tp.edu.tw/~accoweb/index.php?option=com_content&view=category&id=31&Itemid=48" title="點選此項目會另開視窗" target="_blank">預決算書公開專區</a><!--公開專區--></span></td>
		<td><a href="https://www.edusave.edu.tw/school/School_index.aspx?school_sn=273" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">教育儲蓄戶</span></a></td>
		</tr>
        <tr> 
                <td><a href="http://www.ck.tp.edu.tw/~comi/09.html" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">反霸凌專區</span></a></td>
				<td><a href="http://web2.ck.tp.edu.tw/~mathweb/index.php?option=com_content&view=section&id=5&Itemid=35" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">通訊解題</span></a></td>
		<td><a href="https://eteacher.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">網路素養與認知</span></a></td>
		</tr>
 	<tr> 
                <td><a href="https://sites.google.com/site/ckgender/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">性別平等教育網</span></a></td>
				<td><a href="https://sites.google.com/site/ckfamilyedu/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">家庭教育網</span></a></td>
		<td><a href="http://enc.moe.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size: 10pt">反毒─紫錐花運動</span></a></td>
		</tr>
 	<tr> 
                <td><a href="http://report.mnd.gov.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">104年國防報告書</span></a></td>
				<td><a href="http://c2.police.taipei/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">反詐騙專區</span></a></td>
		<td></td>
		</tr>
        <tr>
        	<td colspan="3">
			<a href="https://www.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><img src="./images/www_tp_edu.png" width="160"></a>
			<a href="http://weather.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><img src="./images/weather_tp.jpg" width="160"></a>
			<a href="https://hello.gov.taipei" title="點選此項目會另開視窗" target="_blank"><img src="./images/simple_petition_system_cht.png" width="160"></a>
			</td>	
        </tr>  
	<tr>
		<td colspan="3"><a href="http://cooc.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><img src="COOC.png" width="320"></a></td>	
	</tr>
	<tr>
		<td colspan="3"><a href="http://cooc.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">臺北酷課雲</span></a></td>
	</tr>
	<tr>
		<td colspan="3"><a href="http://106entry.ck.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><img src="106entry.jpg" width="320"></a></td>	
	</tr>
	<tr>
		<td colspan="3"><a href="http://106entry.ck.tp.edu.tw/" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">106學年度全國高級中等學校免試入學委員會</span></a></td>
	</tr>
	<tr>
		<td colspan="3"><a href="http://www.nhi.gov.tw/webdata/webdata.aspx?menu=9&menu_id=1121&webdata_id=5296&WD_ID=1121" title="點選此項目會另開視窗" target="_blank"><img src="health.png" width="320"></a></td>	
	</tr>
	<tr>
		<td colspan="3"><a href="http://www.nhi.gov.tw/webdata/webdata.aspx?menu=9&menu_id=1121&webdata_id=5296&WD_ID=1121" title="點選此項目會另開視窗" target="_blank"><span style="font-size:10pt;">中央健康保險署分級醫療專區</span></a></td>
	</tr>
            </table></td>
          <!--     </tr>-->
        </table>
        </td>
    </tr>
    <tr>
        <td><img src="images/top_img.jpg" width="780" height="8" border="0" alt="版面下方排版用圖片"></td>
    </tr>
    <tr>
        <td>
		   ﻿<table width="97%" align="center" cellpadding="0" cellspacing="0" summary="此為排版用表格">
    <tr>
        <td bgcolor="#E5D6AF" align="center">
            <p><a href="accesskey.php" accesskey="B" title="下方學校相關資訊，點選連結至快捷鍵說明"><font color="#E5D6AF"><span style="font-size:10pt;">:::</span></font></a><font color="#333333"><span style="font-size:10pt;"> &nbsp;&nbsp;<a href="websecurity.htm" title="網站安全政策">網站安全政策</a>&nbsp;&nbsp;<a href="privacy.htm" title="隱私權政策">隱私權政策</a>&nbsp;&nbsp; 
        <a href="copyright.htm" title="著作權聲明">著作權聲明</a>&nbsp;&nbsp;<a href="http://www.taipei.gov.tw/MP_100032.html">本站使用正體字</a></span></font></p>
        </td>
        <td align="center" bgcolor="#E5D6AF">
            <p><img src="images/ck_services_email.jpg" width="176" height="23" border="0" alt="本校意見信箱"></p>
        </td>
    </tr>
    <tr>
        <td bgcolor="#E5D6AF" align="center">
            <p><font color="#333333"><span style="font-size:10pt;"> &nbsp;&nbsp;台北市立建國高級中學&nbsp;&nbsp; (10066)台北市中正區南海路56號&nbsp;&nbsp; 
        TEL:886-2-23034381</span></font></p>
        </td>
        <td align="center" bgcolor="#E5D6AF">
			<p><a href="https://hello.gov.taipei"><img src="images/hellogov.png" height="31" border="0" alt="臺北市單一陳情系統"></a>
            <a href="http://www.handicap-free.nat.gov.tw/Applications/Detail?category=20070226144427"><img src="images/aplus.jpg" width="88" height="31" border="0" alt="本網站通過A+等級無障礙網頁檢測"></a></p>
        </td>
    </tr>
</table>		</td>
    </tr>
</table>

</body>
